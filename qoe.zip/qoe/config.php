<?php //Define your host here.
 $HostName = "localhost";
  //Define your database username here. 
 $HostUser = "lysmums3_admin";
  //Define your database password here.
   $HostPass = "Kmbeatrice@12"; 
   //Define your database name here. 
   $DatabaseName = "lysmums3_qoe"; 
   ?>