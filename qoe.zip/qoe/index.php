<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="dist/img/logo.png">
  <title>Login - <?php include('dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition login-page">
   
    <div class="login-box">
     <!-- /.login-logo -->
      <div class="login-box-body">
         <div class="login-logo">
        <p><img src="dist/img/logo.png" height="100"></p>
        <!-- <b>Fuchs Auto-Parts System</b> -->
      </div>
        <p class="login-box-msg"><b>Sign in to start your session</b></p>
        <form action="login.php" method="post">
          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="Username" name="username" required>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="password" required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
		  
          <div class="row">
			<div class="col-xs-6 pull-right">
			  <button type="reset" class="btn btn-block btn-flat">Clear</button>
            </div><!-- /.col -->
			     <div class="col-xs-6 pull-right">
              <button type="submit" class="btn btn-primary btn-block btn-flat" name="login" default>Sign In</button>
            </div><!-- /.col -->
         <div class="col-xs-12 pull-center" style="height: 30px;">
           <p>   </p>
            </div><!-- /.col -->  
          <?php 
include('dist/includes/dbcon.php');


$query=mysqli_query($con,"select * from user")or die(mysqli_error($con));
  $row=mysqli_fetch_array($query);
    $bid=1;
     $counter=mysqli_num_rows($query);      
    if ($counter==0)
    {?>

      <div class="col-xs-12 pull-center">
           <p align="center">   <a href="#addcategory<?php echo $bid;?>" class="form-control" data-toggle = "modal" data-target="#addcategory<?php echo $bid;?>">System Configuration</a> </p>
            </div><!-- /.col -->  
  <?php  }

?> </div>
        </form>
 <div class="login-box-body">
         <div class="login-logo">
        <!-- <p><img src="dist/img/logo.png" height="100"></p> -->
        <!-- <b>Fuchs Auto-Parts System</b> -->
      </div>
        <p class="login-box-msg">© 2021 QOE. All rights reserved by <a href="http://lysmu.ieeinnovations.com/"></a>.</p>

      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->
      
    <!-- add category -->
                <div id = "addcategory<?php echo $bid;?>" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
                     <div class="modal-dialog modal-sm">
                                <div class="modal-content">

                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                                    </button>
                                    <h4 class="modal-title" id="myModalLabel2">Admin and system setting</h4>
                                  </div>
                                  <div class="modal-body">
                                   <form method = "POST" action = ""> 
                        <label >Admin Full Name</label>         
                        <input type="text" class="form-control" name = "name" value=""  >
                        <label >User Name</label>         
                        <input type="text" class="form-control" name = "uname" value=""  >
                        <label >Password</label>         
                        <input type="password" class="form-control" name = "pwd" value=""  >
                        <label >Pharmacy/Drugshop Name</label>         
                        <input type="text" class="form-control" name = "pname" value=""  >
                         <label >Physical address</label>
                        
                        <input type="text" name="address" class="form-control" placeholder="District-Country">
                        <label >Postal Address)</label> 
                        <input type="Postal" name="postal" class="form-control" placeholder="P.O.Box.000"> 
                        
                        <label >Email Address</label>         
                        <input type="text" class="form-control" name = "email" value=""  >
                        <label >Telephone Number</label>         
                        <input type="text" class="form-control" name = "tel" value=""  >
                        <label >TIN</label>         
                        <input type="number" class="form-control" name = "tin" value=""  >
                        <label >Slogan</label>  
                        <textarea type="text" name="slogan" class="form-control"></textarea>  
                        <br/><br/>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button  name = "addcategory" class="btn btn-primary">Submit Details</button>
                        
                      </form>
                      </div>
                                  <div class="modal-footer">
                                    
                                  </div>
                                </div>
                              </div>
                  </div>       
   
   <?php if(isset($_POST['addcategory'])){
      $name = $_POST['name'];
      $username = $_POST['uname'];
      $password = $_POST['pwd'];
      $pname = $_POST['pname'];
      $address = $_POST['address'];
      $tel = $_POST['tel'];
      $email = $_POST['email'];
      $tin = $_POST['tin'];
      $p = $_POST['postal'];
      $slogan = $_POST['slogan'];
      mysqli_query($con,"INSERT INTO branch(branch_name,branch_address,branch_contact,email,tin,slogan,postal) 
      VALUES('$pname','$address','$tel','$email','$tin','$slogan','$p')")or die(mysqli_error($con));  
      mysqli_query($con,"INSERT INTO user(name,username,password,status)
      VALUES('$name','$username','$password','active')")or die(mysqli_error($con));

      echo "<script type='text/javascript'>alert('Successfully Configured PMY-POS!');</script>";
            echo "<script>document.location='index.php'</script>";  
   }?>
<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
  </body>
</html>
