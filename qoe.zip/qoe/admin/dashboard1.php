<?php
error_reporting(1);
include 'header.php';
function getHoursMinutes($seconds, $format = '%02d:%02d') {

    if (empty($seconds) || ! is_numeric($seconds)) {
        return false;
    }

    $minutes = round($seconds / 60);
    $hours = floor($minutes / 60);
    $remainMinutes = ($minutes % 60);

    return sprintf($format, $hours, $remainMinutes);
}
?>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
       <?php include 'main_sidebar.php';?>

        <!-- top navigation -->
       <?php include 'top_nav.php';?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main"> 
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12" >
        <div class="x_panel">
                  <div class="x_title">
                      
          <div class = "col-md-11 col-lg-11 col-xs-11">
            <br/>
          <form class="form-horizontal " action = "" method = "POST">  
            <div class="col-md-7">
            <label class="control-label">List of Devices and Wifi Details</label>
          
              </div>
              <div class="col-md-1 "><h2> </h2></div>
              
               <div class="col-md-1">
                          
                          </div>
              <div class="col-md-1">
                          

                          </div>                   
                          <div class="col-md-1">
                           
                          </div>
                          <div class="col-md-1">
                           </div>
                        
                      
          </form>
        </div>
        <div class = "col-md-1 col-lg-1 col-xs-1" align="right">
          <p > <label></label></p>
        <button class="btn-default" onclick="PrintList();"><i class="fa fa-print"></i></button> 
        <button class="btn-default" onclick="exportTableToExcel('tblData', 'wifi-data')"><i class="fa fa-pencil"></i></button> 
        </div>
          </div>
          </div>
          <?php 
          include 'dbcon.php';
          $no=0;
          ?>
         <form class="form-horizontal " action = "" method = "POST"> 
          <div class = "col-md-12 col-lg-12 col-xs-12">

           
            <div class = "x-panel">
              
             <table id="tblData" class="table table-striped table-bordered">
               <thead>
                <tr>
                  <th>*</th>
                  <th>Date</th>
                  <th> User Device </th>
                  <th> User Experience </th>
                              <th> Faculty </th>
                               <th>Meeting Application.</th>
                               <th>Time Taken</th>
                                <th>Internet Bandwidth</th>
                                <th>Status</th>
                               <th>Users Comment</th>
                                 
                </tr>
               </thead>
               <tbody>
                <?php 
                 
                    $query1=mysqli_query($con,"SELECT id,user_machine,faculty,app, SUM(period) AS period,bandwidth,status,date,rate,comment from wifi  GROUP BY  user_machine,faculty,date")or die(mysqli_error($con));
                 
                   
                  
                  while ($row1=mysqli_fetch_array($query1)){
                      $id=$row1['id'];

                      $no=$no+1;
                    //  $storeb=$row1['store_branch'];
                    // if($storeb=2){ 
                  ?>  

                <tr>
                    <td> <?php echo $no;?></td>
                <td><?php echo $row1['date']; ?></td>
                
              
                  <td><?php echo $row1['user_machine'];?></td>
                   <td> <?php echo $row1['rate'];?></td> 
                  <td><?php echo $row1['faculty'];?></td>
                  <td><?php echo $row1['app'];?></td>
                  <td><?php $p= $row1['period'];
                  echo getHoursMinutes($p, '%d hours and %d minutes');
                  
                  
                  ?></td>
                  <td><?php echo $row1['bandwidth'];?></td>
                  <td><?php echo $row1['status']; ?></td>
                  <td><?php echo $row1['comment']; ?></td>
               
                                
                </tr>
                     <?php }?>
               </tbody>               
             </table>
             
             
            
            </div>

          </div>
          <!-- <div class = "col-md-8 col-lg-8 col-xs-8">
            <input name="itemid" type="checkbox" value="<?php echo $id; ?>"> <b>Select All </b> 
          </div>
          <div class = "col-md-4 col-lg-4 col-xs-4" align="right">
               <INPUT type="button" name="deleted" value="Multiple Stock Delete " onclick="deleteRow('dataTable')" class="btn btn-danger" />
               <button name="deleted" class="btn btn-danger">Multiple Stock Delete </button>
               
          </div> -->
        </div>
      </div>
        </div>
    </form>
        <!-- /page content -->

        <!-- footer content -->
        <?php 
        if (isset($_POST['deleted'])) {
          $cnt=array();
           $cnt=count($_POST['itemid']);
           for($i=0;$i<$cnt;$i++)
            {
               $iid=$_POST['itemid'][$i];
               
                mysqli_query($con,"DELETE from  items  WHERE id='$iid'")or die(mysqli_error($con));
                   

            }
           echo "<script type='text/javascript'>alert('Item Successfully deleted!');</script>";
                   echo("<meta http-equiv='refresh' content='1'>");
        }
        if (isset($_POST['setbelow'])) {
                  $id = $_POST['item_id'];
                  $qty = $_POST['qty'];
                  mysqli_query($con,"UPDATE items SET bstock='$qty' WHERE id='$id'")or die(mysqli_error($con));
                           
                        
             echo "<script type='text/javascript'>alert('Below stock quantity Successfully set!');</script>";
             echo("<meta http-equiv='refresh' content='1'>");
                 }

                 if (isset($_POST['addpending'])) {
                  $id = $_POST['item_id'];
                  // $qty = $_POST['qty'];
                  mysqli_query($con,"UPDATE items SET pending='Yes' WHERE id='$id'")or die(mysqli_error($con));
                           
                        
             echo "<script type='text/javascript'>alert('Stock Item added to pending!');</script>";
             echo("<meta http-equiv='refresh' content='1'>");
                 }

                if (isset($_POST['delete'])) {
                  $id = $_POST['item_id'];
                   mysqli_query($con,"DELETE from  items  WHERE id='$id'")or die(mysqli_error($con));
                   echo "<script type='text/javascript'>alert('Item Successfully deleted!');</script>";
                   echo("<meta http-equiv='refresh' content='1'>");
                }
                
                if (isset($_POST['update'])) {
                  $id = $_POST['item_id'];
                 $name = $_POST['name'];
                            $category = $_POST['category'];
                            $co = $_POST['co'];
                            $bn = $_POST['bno'];
                            $cprice = $_POST['price'];
                           $pkg = $_POST['pkg'];
                            $unit = $_POST['unit'];
                            $serial=$_POST['serial'];
                            //$sp=$_POST['sprice'][$key];
                           // $q=$_POST['qty'][$key];
                            $location = $_POST['location'];
                            $exdate1=strtotime($_POST['exdate']);
                             $mdate1=strtotime($_POST['mdate']);
                             $exdate=date("Y-m-d",$exdate1);
                             $mdate=date("Y-m-d",$mdate1);
                             $sb_id=$bid;
                           
                            
                            $d= date("M d, Y");
                            
                                mysqli_query($con,"UPDATE items SET company='$co',batch_no='$bn',category='$category',name='$name', costprice='$cprice',serial='$serial',location='$location',unit='$unit',manu_date='$mdate',exp_date='$exdate',type='$pkg' WHERE id='$id'")or die(mysqli_error($con));                   
             echo "<script type='text/javascript'>alert('Data Successfully Updated!');</script>";
             echo("<meta http-equiv='refresh' content='1'>");   
                }           
           if(isset($_POST['importshopstock'])){

                  $store = $branch_id;
                  $d= date("M d, Y");
                            $filename=$_FILES["file"]["tmp_name"];    


                            if($_FILES["file"]["size"] > 0)
                               {
                                  $file = fopen($filename, "r");
                                  while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
                                     {
                                      $total=$getData[1]*$getData[3];
                                      $query=mysqli_query($con,"SELECT * from items where name='".$getData[0]."'  AND branch_id='$branch_id'")or die(mysqli_error($con));
                        $row=mysqli_fetch_array($query);
                                   $iid=$row['id'];
                        $query1=mysqli_query($con,"SELECT * from stock_shop where prod_id='$iid'")or die(mysqli_error($con));
                            $row1=mysqli_fetch_array($query1);
                               $counter=mysqli_num_rows($query1);
                            if ($counter == 0) 
                          { 
                          mysqli_query($con,"INSERT into  stock_shop(branch_id,prod_id, qty, remender,unit_price,date,total_cost) values ('".$branch_id."','".$iid."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$d."','".$total."')")
                             or die(mysqli_error($con)); 
                              mysqli_query($con,"UPDATE items SET qty=qty+'".$getData[2]."' where id='$iid'")
                             or die(mysqli_error($con));
                          }  else {
                              mysqli_query($con,"UPDATE stock_shop SET remender=remender+'".$getData[2]."',unit_price='".$getData[3]."' where prod_id='$iid'") or die(mysqli_error($con)); 
                              mysqli_query($con,"UPDATE items SET qty=qty+'".$getData[2]."' where id='$iid'")
                             or die(mysqli_error($con));
                           }

                                     }
                                
              
                                   fclose($file); 
                                   echo "<script type=\"text/javascript\">
                                    alert(\"CSV File has been successfully Imported.\");
                                   
                                  </script>"; 

      
                               }

                  }


                ?>
        <?php include 'footer.php'; ?>
        <!-- /footer content -->
      </div>
    </div>

  <?php include 'datatable_script.php';?>
    <!-- /gauge.js -->
  </body>
</html>
<SCRIPT language="javascript">
   function PrintList() {
     var printContents = document.getElementById('hidden_list').innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
     window.location.reload();
}
  function exportTableToExcel(tableID, filename = ''){
      var downloadLink;
      var dataType = 'application/vnd.ms-excel';
      var tableSelect = document.getElementById(tableID);
      var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
      
      // Specify file name
      filename = filename?filename+'.xls':'shop_stock.xls';
      
      // Create download link element
      downloadLink = document.createElement("a");
      
      document.body.appendChild(downloadLink);
      
      if(navigator.msSaveOrOpenBlob){
          var blob = new Blob(['\ufeff', tableHTML], {
              type: dataType
          });
          navigator.msSaveOrOpenBlob( blob, filename);
      }else{
          // Create a link to the file
          downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
      
          // Setting the file name
          downloadLink.download = filename;
          
          //triggering the function
          downloadLink.click();
      }
  }

    function addRow(tableID) {

      var table = document.getElementById(tableID);

      var rowCount = table.rows.length;
      var row = table.insertRow(rowCount);

      var colCount = table.rows[0].cells.length;

      for(var i=0; i<colCount; i++) {

        var newcell = row.insertCell(i);

        newcell.innerHTML = table.rows[0].cells[i].innerHTML;
        //alert(newcell.childNodes);
        switch(newcell.childNodes[0].type) {
          case "text":
              newcell.childNodes[0].value = "";
              break;
          case "checkbox":
              newcell.childNodes[0].checked = false;
              break;
          case "select-one":
              newcell.childNodes[0].selectedIndex = 0;
              break;
        }
      }
    }

    function deleteRow(tableID) {
      try {
      var table = document.getElementById(tableID);
      var rowCount = table.rows.length;

      for(var i=0; i<rowCount; i++) {
        var row = table.rows[i];
        var chkbox = row.cells[0].childNodes[0];
        if(null != chkbox && true == chkbox.checked) {
          if(rowCount <= 1) {
            alert("Cannot delete all the rows.");
            break;
          }
          table.deleteRow(i);
          rowCount--;
          i--;
        }


      }
      }catch(e) {
        alert(e);
      }
    }

  </SCRIPT>