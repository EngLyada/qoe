<?php 
include 'dbcon.php';
	session_start();
	session_destroy();
?>
<script>
	window.location = 'http://ieeinnovations.com/business/qoe';
</script>