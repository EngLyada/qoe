<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Menu</h3>
                <ul class="nav side-menu">
                  <li> 
                    <li><a href="dashboard1.php"><i class="fa fa-history"></i> Home<span class="fa fa-chevron-right"></span></span></a></li>
                   </ul>
                    </li>   
				   
                   </ul>

              </div>
            </div>