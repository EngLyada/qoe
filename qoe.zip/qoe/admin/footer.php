<footer>
          <div class="pull-center">
           Copyright © <?php echo date('Y');?> QOE. All rights reserved by <a href="http://lysmu.ieeinnovations.com/">LYSMU LTD</a>.
          </div>
          <div class="clearfix"></div>
        </footer>