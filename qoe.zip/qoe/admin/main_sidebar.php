 <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="images/logo.png" alt="..." class="img-circle profile_img">	
              </div>
              <div class="profile_info">
                <span>Welcome</span>
                <h2><?php echo $user_username;?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <?php include 'sidebar.php';?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
           <?php include 'sidebar2.php';?>
            <!-- /menu footer buttons -->
          </div>
        </div>