<?php include 'header.php';
$branch_id = $_GET['id'];
$branch_name = $_GET['name'];
$querysms=mysqli_query($con,"SELECT * from branch WHERE branch_id='$branch_id'")or die(mysqli_error($con));
                    $rows=mysqli_fetch_array($querysms);
?>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
       <?php include 'main_sidebar.php';?>

        <!-- top navigation -->
       <?php include 'top_nav.php';?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main"> 
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12" >
				<div class="x_panel">
                  <div class="x_title">
				              
					<div class = "col-md-11 col-lg-11 col-xs-11">
						<br/>
					<form class="form-horizontal " action = "" method = "POST">  
						<div class="col-md-7">
					 	<label class="control-label">List of Medicine in Stock</label>
					
					    </div>
					    <div class="col-md-1 "><h2> Select Option:</h2></div>
					    
					     <div class="col-md-1">
                           <button name = "all" class="btn btn-primary">General Stock </button>
                          </div>
						  <div class="col-md-1">
                           <button name = "below" class="btn btn-warning">Below Stock</button>

                          </div>                   
                          <div class="col-md-1">
                           <button name = "out" class="btn btn-danger"> Out of Stock</button>
                          </div>
                          <div class="col-md-1">
                           <button name = "orders" class="btn btn-success">Expired Medicine</button></div>
                        
                      
				 	</form>
				</div>
        <div class = "col-md-1 col-lg-1 col-xs-1" align="right">
          <p > <label></label></p>
        <button class="btn-default" onclick="PrintList();"><i class="fa fa-print"></i></button>  
        </div>
					</div>
					</div>
					<?php 
					include 'dbcon.php';
					$no=0;
					?>
         <form class="form-horizontal " action = "" method = "POST"> 
					<div class = "col-md-12 col-lg-12 col-xs-12">

            <div style="display:none;" id="hidden_list" align="center">
               <style type="text/css">

              .style67 {  font-weight: bold;
                font-family: "Courier New", Courier, monospace;
              }
              .style68 {font-size: 18px}
              .style69 {font-size: 18px}
              .style71 {font-size: 24px}
              .style8 {color: #003366}

              </style>        
              <table >
               <thead>
                 <tr >
                  <td  align="left" valign="top" colspan="5">
                <table width="95%"  border="0" style="width: 100%">
                    <tr>
                      <td width="45%"><div align="left" style="font-size:24px"><strong><?php echo $rows['branch_name'];?></strong></div>
                    <div align="left"><strong><?php echo $rows['postal'];?>. </strong></div>
                        <div align="left"><strong><?php echo $rows['branch_address'];?></strong></div>
                    <div align="left"><strong><?php echo $rows['slogan'];?></strong></div>
                    <div align="left">TIN:<?php echo $rows['tin'];?></div>
                    </td>
                    <td width="55%"  align="right" > <div>Tel: <?php echo $rows['branch_contact'];?></div>
                      
                       <div> Email: <?php echo $rows['email'];?></div>
                       
                    
                    </td>
                      </table></td>
                  
                </tr>
                      <tr width="1000">
                        <td height="16" colspan="5"><div  style="width:100%;display: inline-block;border-bottom: 2px solid #009900; color: #009900;"></div></td>
                      </tr>
                      <tr>
                        <td colspan="5"><div align="center">  LIST OF SALES</div></td>
                      </tr>
                      <tr>
                        <td colspan="10"><div align="center"> </div></td>
                      </tr>
                      <tr width="1000">
                        <td height="16" colspan="5"><div  style="width:100%;display: inline-block;border-bottom: 2px solid #009900; color: #009900;"></div></td>
                      </tr>
                      <?php 
                     $uid= $_SESSION['id'];
                    $q= mysqli_query($con,"SELECT* from user WHERE user_id='$uid'")or die(mysqli_error($con));
                            $row=mysqli_fetch_array($q);
                            $n=$row['name'];
                      ?>
                      <tr width="1000">
                        <td width="936" colspan="3"><div class="style68" >Processed by:<?php echo $n;?> </div></td>
                       
                        <td width="278" align="right" colspan="2"> Printed on:<?php echo (date('d-m-Y'));?> </td>
                        
                      </tr>
                      
                      <tr width="1000">
                        <td height="16" colspan="5"><div  style="width:100%;display: inline-block;border-bottom: 2px solid #009900; color: #009900;"></div></td>
                      </tr>
                <tr>
                  <th>*</th>
                  <th> Name </th>
                             
                               <th>Category</th>
                                
                                <th>Unit</th>
                              
                                
                                
                                <th>Price</th>
                                
                   

                                 
                </tr>
               </thead>
               <tbody>
                <?php 
                  $today=date('Y-m-d');
                $query1=mysqli_query($con,"SELECT * from items  WHERE branch_id='$branch_id' AND name!='Name'  ORDER BY id ASC")or die(mysqli_error($con)); 
                
                  
                  while ($row1=mysqli_fetch_array($query1)){
                      $id=$row1['id'];

                      $no=$no+1;
                    //  $storeb=$row1['store_branch'];
                    // if($storeb=2){ 
                  ?>  

                <tr>

                  <td width="30"> <?php echo $no;?> . </td>
              
                  <td><?php echo $row1['name'];?></td>
                 
                  <td width="100"><?php echo $row1['category'];?></td>
                  <td><?php echo $row1['unit'];?></td>
                  <td><?php echo $row1['price'];?></td>
                                
                </tr>
                    
                <?php }?>
               </tbody>               
             </table>


            </div>


						<div class = "x-panel">
              
						 <table id="datatable" class="table table-striped table-bordered">
               <thead>
                <tr>
									<th>*</th>
									<th> Name </th>
                              <th> Company </th>
                               <th>Batch No.</th>
                               <th>Category</th>
                                <th>Manufacture Date</th>
                                <th>Expiry Date</th>
                                <th>Unit</th>
                                <th>Serial</th>
                                <th>Quantity</th>
                                <th>Cost</th>
                                <th>Seling Price</th>
                                
                                <th>Location</th>
									<th>Action</th>									
								</tr>
							 </thead>
							 <tbody>
							 	<?php	
									$today=date('Y-m-d');
								if(isset($_POST['all'])){
									// $query1=mysqli_query($con,"SELECT stock_shop.*,items.* from stock_shop JOIN items ON items.id=stock_shop.prod_id  WHERE stock_shop.branch_id='$branch_id' AND name!='Name'  ORDER BY stock_shop.id ASC")or die(mysqli_error($con));
								$query1=mysqli_query($con,"SELECT * from items  WHERE branch_id='$branch_id' AND name!='Name'  ORDER BY id ASC")or die(mysqli_error($con));	
								}else if(isset($_POST['below'])){
								 $query1=mysqli_query($con,"SELECT * from items  WHERE branch_id='$branch_id' AND name!='Name' AND remender>0 AND remender< bstock ORDER BY id ASC")or die(mysqli_error($con));
								}else if( isset($_POST['out'])){
									$query1=mysqli_query($con,"SELECT * from items  WHERE branch_id='$branch_id' AND name!='Name' AND remender=0  ORDER BY id ASC")or die(mysqli_error($con));

							   }else if( isset($_POST['orders'])){
                  $query1=mysqli_query($con,"SELECT * from items  WHERE branch_id='$branch_id' AND name!='Name' AND exp_date < '$today'  ORDER BY id ASC")or die(mysqli_error($con));

                 }

                 else{
							   	 	$query1=mysqli_query($con,"SELECT * from items  WHERE branch_id='$branch_id' AND name!='Name'  ORDER BY id ASC")or die(mysqli_error($con));
							   }
									 
									
									while ($row1=mysqli_fetch_array($query1)){
											$id=$row1['id'];

											$no=$no+1;
										// 	$storeb=$row1['store_branch'];
										// if($storeb=2){	
									?>  

								<tr>

									<td> <?php echo $no;?></td>
              
									<td><?php echo $row1['name'];?></td>
                  <td><?php echo $row1['company'];?></td>
									<td><?php echo $row1['batch_no'];?></td>
									<td><?php echo $row1['category'];?></td>
									<td><?php echo $row1['manu_date'];?></td>
									<td><?php echo $row1['exp_date']; if( isset($_POST['orders'])){?><div style="background: red; color: white; " >EXPIRED</div><?php }?></td>
									<td><?php echo $row1['unit'];?></td>
									<td><?php echo $row1['serial'];?></td>
									<td><?php echo $row1['remender'];?> <?php echo $row1['type'];?></td>

									<td><?php echo $row1['costprice'];?></td>
									<td><?php echo $row1['price'];?></td>
									<td><?php echo $row1['location']; ?></td>
									<td>
										
										<a href="#viewitem<?php echo $id;?>" class="btn btn-primary btn-xs" data-toggle = "modal" data-target="#viewitem<?php echo $id;?>"><i class = "fa fa-pencil"></i> View</a>
                    	
										<a href="#transfer<?php echo $id;?>" class="btn btn-success btn-xs" data-toggle = "modal" data-target="#transfer<?php echo $id;?>"><i class = "fa fa-pencil"></i> Update Stock</a>
										<a href="#edititem<?php echo $id;?>" class="btn btn-warning btn-xs" data-toggle = "modal" data-target="#edititem<?php echo $id;?>"><i class = "fa fa-pencil"></i></a>
                    					<a href="#below<?php echo $id;?>" class="btn btn-primary btn-xs" data-toggle = "modal" data-target="#below<?php echo $id;?>">B/stock</a>
                    					<a href="#pending<?php echo $id;?>" class="btn btn-warning btn-xs" data-toggle = "modal" data-target="#pending<?php echo $id;?>">+ Pending</a>
										
									</td>
																
								</tr>
										<?php  

										 include 'viewitemsprice.php';
										 include 'save_transfer.php';
										 ?>
										<!--  view item details -->
										<!-- restock items to this branch -->
										<div id = "below<?php echo $id;?>" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
                     <div class="modal-dialog modal-sm">
                                <div class="modal-content">

                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                                    </button>
                                    <h4 class="modal-title" id="myModalLabel2">Set below stock quantity</h4>
                                  </div>
                                  <div class="modal-body">
                                   <form method = "POST" action = ""> 
                         <input type="hidden" name="item_id" value="<?php echo $id;?>">
                        
                        <label >Quantity </label>         
                        <input type="number" class="form-control" name = "qty" value=""  required>
                        
                        <br/><br/>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button  name = "setbelow" class="btn btn-primary">Save Quantity</button>
                        
                      </form>
                      </div>
                                  <div class="modal-footer">
                                    
                                  </div>
                                </div>
                              </div>
                  </div>
                  <!-- adding to pending -->
                  <div id = "pending<?php echo $id;?>" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
                     <div class="modal-dialog modal-sm">
                                <div class="modal-content">

                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                                    </button>
                                    <h4 class="modal-title" id="myModalLabel2">Are you sure you want to add this Medicine to Pending?</h4>
                                  </div>
                                  <div class="modal-body">
                                   <form method = "POST" action = ""> 
                         <input type="hidden" name="item_id" value="<?php echo $id;?>">
                        
                        
                        
                        <br/><br/>
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                        <button  name = "addpending" class="btn btn-primary">Yes</button>
                        
                      </form>
                      </div>
                                  <div class="modal-footer">
                                    
                                  </div>
                                </div>
                              </div>
                  </div>
                  <!-- update or delete item -->
                    <div id = "edititem<?php echo $id;?>" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
                     <div class="modal-dialog modal-sm">
                        <div class="modal-content">

                        <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                                    </button>
                                    <h4 class="modal-title" id="myModalLabel2">Edit Medicine Details</h4>
                                  </div>
                                  <div class="modal-body">
                                   <form method = "POST" action = ""> 
                         <input type="hidden" name="item_id" value="<?php echo $id;?>">
                        
                        <label >Name </label>         
                        <input type="text" class="form-control" name = "name" value="<?php echo $row1['name'];?>"  >
                        <br/>
                        <label >Company</label>         
                        <input type="text" class="form-control" name = "co" value="<?php echo $row1['company'];?>"  >
                        <br>
                        <label >Batch No </label>         
                        <input type="text" class="form-control" name ="bno" value="<?php echo $row1['batch_no'];?>" >
                        <br/>
                        <label >Category </label>         
                        <select name="category" class="form-control">
                           <option id="<?php echo $row['category'];?>" ><?php echo $row['category']; ?></option>
                            <?php
                                 $query=mysqli_query($con,"select * from category")or die(mysqli_error($con));
                                   while ($row=mysqli_fetch_array($query)){
                                   ?>
                                    <option id="<?php echo $row['name'];?>" ><?php echo $row['name']; ?></option>
                                <?php } ?>
                          </select>
                        <br/>
                        <label >Manufactured Date </label>         
                        <input type="date" class="form-control" name = "mdate" value="<?php echo $row1['manu_date'];?>" >
                        <br/>
                        <label >Expirely Date </label>         
                        <input type="date" class="form-control" name = "exdate" value="<?php echo $row1['exp_date'];?>" >
                        <br/>
                       <label >Packaging </label> 
                        <select name = "pkg" class="form-control" >
                          <option id="<?php echo $row1['type'];?>"><?php echo $row1['type'];?></option>
                          <option id="PC" >PC(S)</option>
                           <option id="PR" >PAIR(S)</option>
                           <option id="Tube" >Tube(S)</option>
                           <option id="PKT" >PKT(S)</option>
                            <option id="SRP" >SRP(S)</option>
                           <option id="BTL" >BTL(S)</option>
                           <option id="BOX" >BOX(S)</option>
                          </select>
                        
                         
                        <label>Unit</label>         
                        <input type="text" class="form-control" name = "unit" value="<?php echo $row1['unit'];?>"  >
                        <br/>
                        <label >Cost (Rate) </label>         
                        <input type="number" class="form-control" name = "price" value="<?php echo $row1['costprice'];?>"  >
                        <br/>
                        <label >Serial </label>         
                        <input type="text" class="form-control" name = "serial" value="<?php echo $row1['serial'];?>" >
                        <br/>
                        <label >Location </label>         
                       <input type="text" class="form-control" name = "location" value="<?php echo $row1['location'];?>"  >
                        <br/><br/>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button  name = "update" class="btn btn-primary">Save changes</button>
                        <button  name = "delete" class="btn btn-danger">Delete</button>
                      </form>
                      </div>
                                  <div class="modal-footer">
                                    
                                  </div>
                                </div>
                              </div>
                  </div>

								<?php }?>
							 </tbody>								
						 </table>
             
             
						
            </div>

					</div>
          <!-- <div class = "col-md-8 col-lg-8 col-xs-8">
            <input name="itemid" type="checkbox" value="<?php echo $id; ?>"> <b>Select All </b> 
          </div>
          <div class = "col-md-4 col-lg-4 col-xs-4" align="right">
               <INPUT type="button" name="deleted" value="Multiple Stock Delete " onclick="deleteRow('dataTable')" class="btn btn-danger" />
               <button name="deleted" class="btn btn-danger">Multiple Stock Delete </button>
               
          </div> -->
				</div>
			</div>
        </div>
		</form>
        <!-- /page content -->

        <!-- footer content -->
        <?php 
        if (isset($_POST['deleted'])) {
          $cnt=array();
           $cnt=count($_POST['itemid']);
           for($i=0;$i<$cnt;$i++)
            {
               $iid=$_POST['itemid'][$i];
               
                mysqli_query($con,"DELETE from  items  WHERE id='$iid'")or die(mysqli_error($con));
                   

            }
           echo "<script type='text/javascript'>alert('Item Successfully deleted!');</script>";
                   echo("<meta http-equiv='refresh' content='1'>");
        }
        if (isset($_POST['setbelow'])) {
                  $id = $_POST['item_id'];
                  $qty = $_POST['qty'];
                  mysqli_query($con,"UPDATE items SET bstock='$qty' WHERE id='$id'")or die(mysqli_error($con));
                           
                        
             echo "<script type='text/javascript'>alert('Below stock quantity Successfully set!');</script>";
             echo("<meta http-equiv='refresh' content='1'>");
                 }

                 if (isset($_POST['addpending'])) {
                  $id = $_POST['item_id'];
                  // $qty = $_POST['qty'];
                  mysqli_query($con,"UPDATE items SET pending='Yes' WHERE id='$id'")or die(mysqli_error($con));
                           
                        
             echo "<script type='text/javascript'>alert('Stock Item added to pending!');</script>";
             echo("<meta http-equiv='refresh' content='1'>");
                 }

                if (isset($_POST['delete'])) {
                  $id = $_POST['item_id'];
                   mysqli_query($con,"DELETE from  items  WHERE id='$id'")or die(mysqli_error($con));
                   echo "<script type='text/javascript'>alert('Item Successfully deleted!');</script>";
                   echo("<meta http-equiv='refresh' content='1'>");
                }
                
                if (isset($_POST['update'])) {
                  $id = $_POST['item_id'];
                 $name = $_POST['name'];
                            $category = $_POST['category'];
                            $co = $_POST['co'];
                            $bn = $_POST['bno'];
                            $cprice = $_POST['price'];
                           $pkg = $_POST['pkg'];
                            $unit = $_POST['unit'];
                            $serial=$_POST['serial'];
                            //$sp=$_POST['sprice'][$key];
                           // $q=$_POST['qty'][$key];
                            $location = $_POST['location'];
                            $exdate1=strtotime($_POST['exdate']);
                             $mdate1=strtotime($_POST['mdate']);
                             $exdate=date("Y-m-d",$exdate1);
                             $mdate=date("Y-m-d",$mdate1);
                             $sb_id=$bid;
                           
                            
                            $d= date("M d, Y");
                            
                                mysqli_query($con,"UPDATE items SET company='$co',batch_no='$bn',category='$category',name='$name', costprice='$cprice',serial='$serial',location='$location',unit='$unit',manu_date='$mdate',exp_date='$exdate',type='$pkg' WHERE id='$id'")or die(mysqli_error($con));                   
             echo "<script type='text/javascript'>alert('Data Successfully Updated!');</script>";
             echo("<meta http-equiv='refresh' content='1'>");   
                }           
           if(isset($_POST['importshopstock'])){

                  $store = $branch_id;
                  $d= date("M d, Y");
                            $filename=$_FILES["file"]["tmp_name"];    


                            if($_FILES["file"]["size"] > 0)
                               {
                                  $file = fopen($filename, "r");
                                  while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
                                     {
                                      $total=$getData[1]*$getData[3];
                                      $query=mysqli_query($con,"SELECT * from items where name='".$getData[0]."'  AND branch_id='$branch_id'")or die(mysqli_error($con));
                        $row=mysqli_fetch_array($query);
                                   $iid=$row['id'];
                        $query1=mysqli_query($con,"SELECT * from stock_shop where prod_id='$iid'")or die(mysqli_error($con));
                            $row1=mysqli_fetch_array($query1);
                               $counter=mysqli_num_rows($query1);
                            if ($counter == 0) 
                          { 
                          mysqli_query($con,"INSERT into  stock_shop(branch_id,prod_id, qty, remender,unit_price,date,total_cost) values ('".$branch_id."','".$iid."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$d."','".$total."')")
                             or die(mysqli_error($con)); 
                              mysqli_query($con,"UPDATE items SET qty=qty+'".$getData[2]."' where id='$iid'")
                             or die(mysqli_error($con));
                          }  else {
                              mysqli_query($con,"UPDATE stock_shop SET remender=remender+'".$getData[2]."',unit_price='".$getData[3]."' where prod_id='$iid'") or die(mysqli_error($con)); 
                              mysqli_query($con,"UPDATE items SET qty=qty+'".$getData[2]."' where id='$iid'")
                             or die(mysqli_error($con));
                           }

                                     }
                                
              
                                   fclose($file); 
                                   echo "<script type=\"text/javascript\">
                                    alert(\"CSV File has been successfully Imported.\");
                                   
                                  </script>"; 

      
                               }

                  }


                ?>
        <?php include 'footer.php'; ?>
        <!-- /footer content -->
      </div>
    </div>

	<?php include 'datatable_script.php';?>
    <!-- /gauge.js -->
  </body>
</html>
<SCRIPT language="javascript">
   function PrintList() {
     var printContents = document.getElementById('hidden_list').innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
     window.location.reload();
}
	function exportTableToExcel(tableID, filename = ''){
	    var downloadLink;
	    var dataType = 'application/vnd.ms-excel';
	    var tableSelect = document.getElementById(tableID);
	    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
	    
	    // Specify file name
	    filename = filename?filename+'.xls':'shop_stock.xls';
	    
	    // Create download link element
	    downloadLink = document.createElement("a");
	    
	    document.body.appendChild(downloadLink);
	    
	    if(navigator.msSaveOrOpenBlob){
	        var blob = new Blob(['\ufeff', tableHTML], {
	            type: dataType
	        });
	        navigator.msSaveOrOpenBlob( blob, filename);
	    }else{
	        // Create a link to the file
	        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
	    
	        // Setting the file name
	        downloadLink.download = filename;
	        
	        //triggering the function
	        downloadLink.click();
	    }
	}

    function addRow(tableID) {

      var table = document.getElementById(tableID);

      var rowCount = table.rows.length;
      var row = table.insertRow(rowCount);

      var colCount = table.rows[0].cells.length;

      for(var i=0; i<colCount; i++) {

        var newcell = row.insertCell(i);

        newcell.innerHTML = table.rows[0].cells[i].innerHTML;
        //alert(newcell.childNodes);
        switch(newcell.childNodes[0].type) {
          case "text":
              newcell.childNodes[0].value = "";
              break;
          case "checkbox":
              newcell.childNodes[0].checked = false;
              break;
          case "select-one":
              newcell.childNodes[0].selectedIndex = 0;
              break;
        }
      }
    }

    function deleteRow(tableID) {
      try {
      var table = document.getElementById(tableID);
      var rowCount = table.rows.length;

      for(var i=0; i<rowCount; i++) {
        var row = table.rows[i];
        var chkbox = row.cells[0].childNodes[0];
        if(null != chkbox && true == chkbox.checked) {
          if(rowCount <= 1) {
            alert("Cannot delete all the rows.");
            break;
          }
          table.deleteRow(i);
          rowCount--;
          i--;
        }


      }
      }catch(e) {
        alert(e);
      }
    }

  </SCRIPT>